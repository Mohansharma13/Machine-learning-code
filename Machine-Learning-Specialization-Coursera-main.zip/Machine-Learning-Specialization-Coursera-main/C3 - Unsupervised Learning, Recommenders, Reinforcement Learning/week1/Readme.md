### C3 - Week 1 Solutions


- [Practice quiz : Clustering](https://github.com/greyhatguy007/Machine-Learning-Specialization-Coursera/blob/20e9e2fafcabd86aeeabdda2f79316caba6a5213/C3%20-%20Unsupervised%20Learning,%20Recommenders,%20Reinforcement%20Learning/week1/Practice%20Quiz:%20Clustering)
- [Practice quiz : Anomaly Detection](https://github.com/greyhatguy007/Machine-Learning-Specialization-Coursera/blob/50762882a48709806ca8cfae482eafdb7ccbc394/C3%20-%20Unsupervised%20Learning,%20Recommenders,%20Reinforcement%20Learning/week1/Practice%20Quiz%20:%20Anomaly%20Detection)
  - [Programming Assignment 1](https://github.com/greyhatguy007/Machine-Learning-Specialization-Coursera/blob/078956db6f34d8c9e1dda497cd613922c5146ead/C3%20-%20Unsupervised%20Learning,%20Recommenders,%20Reinforcement%20Learning/week1/C3W1A)
      - [K means](https://github.com/greyhatguy007/Machine-Learning-Specialization-Coursera/blob/078956db6f34d8c9e1dda497cd613922c5146ead/C3%20-%20Unsupervised%20Learning,%20Recommenders,%20Reinforcement%20Learning/week1/C3W1A/C3W1A1/C3_W1_KMeans_Assignment.ipynb)
      - [Anomaly Detection](https://github.com/greyhatguy007/Machine-Learning-Specialization-Coursera/blob/3f7a43ce32bc6bea2fca7bc815ad2a5883422c9b/C3%20-%20Unsupervised%20Learning,%20Recommenders,%20Reinforcement%20Learning/week1/C3W1A/C3W1A2/C3_W1_Anomaly_Detection.ipynb)