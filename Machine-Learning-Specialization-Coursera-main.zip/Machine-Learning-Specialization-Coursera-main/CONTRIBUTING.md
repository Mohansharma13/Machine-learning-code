If you find it useful,

Dropping a *star* would be *motivational* !
